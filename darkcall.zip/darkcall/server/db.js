'use strict';
const Database = require('better-sqlite3');
const fs = require('fs');
const path = require('path');
const dir = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
fs.mkdirSync(path.join(dir, 'uploads'), { recursive: true });
const db = new Database(path.join(dir, 'darkcall.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, handle TEXT UNIQUE NOT NULL, name TEXT NOT NULL, hash TEXT NOT NULL,
  avatar TEXT, settings TEXT NOT NULL DEFAULT '{}', last_seen INTEGER, created INTEGER);
CREATE TABLE IF NOT EXISTS friendships(
  id INTEGER PRIMARY KEY, requester INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  addressee INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status TEXT NOT NULL, created INTEGER, UNIQUE(requester, addressee));
CREATE TABLE IF NOT EXISTS favorites(
  user_id INTEGER NOT NULL, friend_id INTEGER NOT NULL, PRIMARY KEY(user_id, friend_id));
CREATE TABLE IF NOT EXISTS blocks(
  user_id INTEGER NOT NULL, blocked_id INTEGER NOT NULL, PRIMARY KEY(user_id, blocked_id));
CREATE TABLE IF NOT EXISTS messages(
  id INTEGER PRIMARY KEY, from_id INTEGER NOT NULL, to_id INTEGER NOT NULL, type TEXT NOT NULL,
  body TEXT, url TEXT, fname TEXT, reply_to INTEGER, status INTEGER NOT NULL DEFAULT 0,
  created INTEGER NOT NULL, deleted INTEGER NOT NULL DEFAULT 0);
CREATE INDEX IF NOT EXISTS idx_msg_pair ON messages(from_id, to_id, id);
CREATE INDEX IF NOT EXISTS idx_msg_to ON messages(to_id, status);
CREATE TABLE IF NOT EXISTS calls(
  id INTEGER PRIMARY KEY, room TEXT, caller INTEGER NOT NULL, callee INTEGER NOT NULL,
  video INTEGER NOT NULL DEFAULT 0, started INTEGER NOT NULL, status TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS push_subs(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, endpoint TEXT UNIQUE NOT NULL, json TEXT NOT NULL);
`);
module.exports = { db, dir };
