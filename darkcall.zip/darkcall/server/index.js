'use strict';
require('dotenv').config();
const path = require('path'), fs = require('fs'), http = require('http'), crypto = require('crypto');
const express = require('express'), helmet = require('helmet'), rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs'), jwt = require('jsonwebtoken'), multer = require('multer');
const { Server } = require('socket.io');
const { db, dir } = require('./db');

/* ---------- configuração ---------- */
let webpush = null;
if (process.env.VAPID_PUBLIC && process.env.VAPID_PRIVATE) {
  webpush = require('web-push');
  webpush.setVapidDetails(process.env.VAPID_SUBJECT || 'mailto:admin@example.com', process.env.VAPID_PUBLIC, process.env.VAPID_PRIVATE);
}
const secretFile = path.join(dir, 'jwt.secret');
const SECRET = process.env.JWT_SECRET || (fs.existsSync(secretFile) ? fs.readFileSync(secretFile, 'utf8') :
  (() => { const s = crypto.randomBytes(48).toString('hex'); fs.writeFileSync(secretFile, s, { mode: 0o600 }); return s; })());

const app = express();
app.set('trust proxy', 1);
const server = http.createServer(app);
const io = new Server(server, { maxHttpBufferSize: 1e5 });

/* ---------- helpers ---------- */
const now = () => Date.now();
const getUser = id => db.prepare('SELECT * FROM users WHERE id=?').get(id);
const isOnline = id => (io.sockets.adapter.rooms.get('u' + id)?.size || 0) > 0;
const pub = u => u && { id: u.id, handle: u.handle, name: u.name, avatar: u.avatar, online: isOnline(u.id), last_seen: u.last_seen };
const settingsOf = id => { try { return JSON.parse(getUser(id)?.settings || '{}'); } catch { return {}; } };
const meOut = u => ({ ...pub(u), settings: settingsOf(u.id) });
const sign = u => jwt.sign({ id: u.id }, SECRET, { expiresIn: '90d' });
const areFriends = (a, b) => !!db.prepare("SELECT 1 FROM friendships WHERE status='accepted' AND ((requester=? AND addressee=?) OR (requester=? AND addressee=?))").get(a, b, b, a);
const blockedEither = (a, b) => !!db.prepare('SELECT 1 FROM blocks WHERE (user_id=? AND blocked_id=?) OR (user_id=? AND blocked_id=?)').get(a, b, b, a);
const friendIds = uid => db.prepare("SELECT CASE WHEN requester=? THEN addressee ELSE requester END id FROM friendships WHERE status='accepted' AND (requester=? OR addressee=?)").all(uid, uid, uid).map(r => r.id);
const emitToFriends = (uid, ev, p) => friendIds(uid).forEach(f => io.to('u' + f).emit(ev, p));
const msgOut = m => (m.deleted ? { ...m, body: null, url: null, fname: null } : m);
const FILE_URL = /^\/uploads\/[a-f0-9]{32}(\.[a-z0-9]{1,8})?$/;

const SET_KEYS = { ringtone: ['neon', 'pulse', 'orbit'], msgSound: ['pop', 'drop', 'ping'], preview: ['all', 'name', 'none'] };
function cleanSettings(s) {
  const o = {};
  if (!s || typeof s !== 'object') return o;
  for (const k in SET_KEYS) if (SET_KEYS[k].includes(s[k])) o[k] = s[k];
  if (Number.isFinite(+s.volume)) o.volume = Math.min(100, Math.max(0, +s.volume));
  for (const k of ['vibrate', 'silent', 'float', 'notifyOnline']) if (typeof s[k] === 'boolean') o[k] = s[k];
  return o;
}

function iceServers(uid) {
  const s = [{ urls: (process.env.STUN_URL || 'stun:stun.l.google.com:19302').split(',') }];
  if (process.env.TURN_URL && process.env.TURN_SECRET) {
    const user = (Math.floor(Date.now() / 1000) + 6 * 3600) + ':' + uid;
    const credential = crypto.createHmac('sha1', process.env.TURN_SECRET).update(user).digest('base64');
    s.push({ urls: process.env.TURN_URL.split(','), username: user, credential });
  }
  return s;
}

/* push só é enviado para quem está offline */
function push(uid, payload) {
  if (!webpush || isOnline(uid)) return;
  const st = settingsOf(uid);
  if (payload.kind === 'msg' && st.preview === 'none') { payload = { ...payload, title: 'DarkCall', body: 'Nova mensagem' }; }
  else if (payload.kind === 'msg' && st.preview === 'name') payload = { ...payload, body: 'Nova mensagem' };
  db.prepare('SELECT * FROM push_subs WHERE user_id=?').all(uid).forEach(r => {
    webpush.sendNotification(JSON.parse(r.json), JSON.stringify(payload), { TTL: payload.call ? 40 : 86400 })
      .catch(e => { if (e.statusCode === 404 || e.statusCode === 410) db.prepare('DELETE FROM push_subs WHERE id=?').run(r.id); });
  });
}

/* ---------- middleware ---------- */
app.use(helmet({
  contentSecurityPolicy: {
    useDefaults: false,
    directives: {
      defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", 'data:', 'blob:'], mediaSrc: ["'self'", 'blob:'], connectSrc: ["'self'", 'ws:', 'wss:'],
      objectSrc: ["'none'"], frameAncestors: ["'none'"], baseUri: ["'self'"]
    }
  },
  crossOriginEmbedderPolicy: false
}));
app.use(express.json({ limit: '100kb' }));

const uploadDir = path.join(dir, 'uploads');
app.use('/uploads', express.static(uploadDir, {
  index: false, dotfiles: 'deny',
  setHeaders(res, fp) {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Cache-Control', 'private, max-age=86400');
    if (!/\.(png|jpe?g|gif|webp|mp4|webm|mov|mp3|ogg|wav|m4a|weba|opus)$/i.test(fp)) res.setHeader('Content-Disposition', 'attachment');
  }
}));
app.use(express.static(path.join(__dirname, '..', 'public'), {
  setHeaders(res, fp) { if (fp.endsWith('sw.js')) res.setHeader('Cache-Control', 'no-cache'); }
}));

const authLimit = rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false });
const api = express.Router();
app.use('/api', api);

const DUMMY = bcrypt.hashSync('dummy-password', 10);
api.post('/register', authLimit, (req, res) => {
  const handle = String(req.body.handle || '').trim().toLowerCase();
  const name = String(req.body.name || '').trim().slice(0, 40);
  const pw = String(req.body.password || '');
  if (!/^[a-z0-9_]{3,20}$/.test(handle)) return res.status(400).json({ error: 'ID: 3 a 20 letras minúsculas, números ou _' });
  if (!name) return res.status(400).json({ error: 'Informe seu nome' });
  if (pw.length < 8 || pw.length > 100) return res.status(400).json({ error: 'A senha precisa ter de 8 a 100 caracteres' });
  if (db.prepare('SELECT 1 FROM users WHERE handle=?').get(handle)) return res.status(409).json({ error: 'Esse ID já está em uso' });
  const info = db.prepare('INSERT INTO users(handle,name,hash,created,last_seen) VALUES(?,?,?,?,?)').run(handle, name, bcrypt.hashSync(pw, 11), now(), now());
  const u = getUser(info.lastInsertRowid);
  res.json({ token: sign(u), user: meOut(u) });
});
api.post('/login', authLimit, (req, res) => {
  const u = db.prepare('SELECT * FROM users WHERE handle=?').get(String(req.body.handle || '').trim().toLowerCase().replace(/^@/, ''));
  const ok = bcrypt.compareSync(String(req.body.password || ''), u ? u.hash : DUMMY);
  if (!u || !ok) return res.status(401).json({ error: 'ID ou senha incorretos' });
  res.json({ token: sign(u), user: meOut(u) });
});

function auth(req, res, next) {
  try {
    const p = jwt.verify((req.headers.authorization || '').slice(7), SECRET);
    const u = getUser(p.id);
    if (!u) throw new Error('x');
    req.uid = u.id; req.user = u; next();
  } catch { res.status(401).json({ error: 'Não autenticado' }); }
}
api.use(auth);

/* ---------- perfil ---------- */
api.get('/me', (req, res) => res.json(meOut(req.user)));
api.put('/me', (req, res) => {
  const b = req.body || {};
  let { name, avatar } = req.user;
  if (typeof b.name === 'string') { name = b.name.trim().slice(0, 40); if (!name) return res.status(400).json({ error: 'Nome inválido' }); }
  if (b.avatar !== undefined) {
    if (b.avatar !== null && !FILE_URL.test(String(b.avatar))) return res.status(400).json({ error: 'Foto inválida' });
    avatar = b.avatar;
  }
  const st = { ...settingsOf(req.uid), ...cleanSettings(b.settings) };
  db.prepare('UPDATE users SET name=?, avatar=?, settings=? WHERE id=?').run(name, avatar, JSON.stringify(st), req.uid);
  res.json(meOut(getUser(req.uid)));
});
api.get('/config', (req, res) => res.json({ ice: iceServers(req.uid), vapid: process.env.VAPID_PUBLIC || null }));
api.post('/push', (req, res) => {
  const s = req.body || {};
  if (typeof s.endpoint !== 'string' || !/^https:\/\//.test(s.endpoint) || !s.keys) return res.status(400).json({ error: 'Inscrição inválida' });
  db.prepare('INSERT INTO push_subs(user_id,endpoint,json) VALUES(?,?,?) ON CONFLICT(endpoint) DO UPDATE SET user_id=excluded.user_id, json=excluded.json')
    .run(req.uid, s.endpoint, JSON.stringify({ endpoint: s.endpoint, keys: s.keys }));
  res.json({ ok: true });
});

/* ---------- upload ---------- */
const upload = multer({
  limits: { fileSize: 50 * 1024 * 1024, files: 1 },
  storage: multer.diskStorage({
    destination: uploadDir,
    filename(req, f, cb) {
      let ext = path.extname(f.originalname).toLowerCase().replace(/[^.a-z0-9]/g, '').slice(0, 8);
      if (ext === '.' || ['.html', '.htm', '.svg', '.js', '.xhtml', '.xml', '.mjs'].includes(ext)) ext = ext === '.' ? '' : '.bin';
      cb(null, crypto.randomBytes(16).toString('hex') + ext);
    }
  })
});
api.post('/upload', upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Nenhum arquivo' });
  res.json({ url: '/uploads/' + req.file.filename, name: Buffer.from(req.file.originalname, 'latin1').toString('utf8').slice(0, 120), size: req.file.size });
});

/* ---------- amigos ---------- */
api.get('/users/search', (req, res) => {
  const t = String(req.query.q || '').trim().toLowerCase().replace(/^@/, '');
  if (t.length < 2) return res.json([]);
  const like = '%' + t.replace(/[%_\\]/g, '\\$&') + '%';
  const rows = db.prepare("SELECT id,handle,name,avatar FROM users WHERE id!=? AND (handle LIKE ? ESCAPE '\\' OR LOWER(name) LIKE ? ESCAPE '\\') LIMIT 20").all(req.uid, like, like);
  res.json(rows.filter(u => !db.prepare('SELECT 1 FROM blocks WHERE user_id=? AND blocked_id=?').get(u.id, req.uid)).map(u => {
    const f = db.prepare('SELECT * FROM friendships WHERE (requester=? AND addressee=?) OR (requester=? AND addressee=?)').get(req.uid, u.id, u.id, req.uid);
    return { ...u, rel: !f ? null : f.status === 'accepted' ? 'friend' : f.requester === req.uid ? 'sent' : 'incoming' };
  }));
});
api.get('/friends', (req, res) => {
  const rows = db.prepare(`SELECT f.status, f.requester, u.id, u.handle, u.name, u.avatar, u.last_seen,
    EXISTS(SELECT 1 FROM favorites WHERE user_id=? AND friend_id=u.id) fav,
    EXISTS(SELECT 1 FROM blocks WHERE user_id=? AND blocked_id=u.id) blocked
    FROM friendships f JOIN users u ON u.id = CASE WHEN f.requester=? THEN f.addressee ELSE f.requester END
    WHERE f.requester=? OR f.addressee=?`).all(req.uid, req.uid, req.uid, req.uid, req.uid);
  res.json(rows.map(r => ({ id: r.id, handle: r.handle, name: r.name, avatar: r.avatar, last_seen: r.last_seen, status: r.status,
    incoming: r.status === 'pending' && r.requester !== req.uid, fav: !!r.fav, blocked: !!r.blocked, online: isOnline(r.id) })));
});
function acceptFriend(me, other) {
  const r = db.prepare("UPDATE friendships SET status='accepted' WHERE requester=? AND addressee=? AND status='pending'").run(other, me);
  if (r.changes) {
    io.to('u' + other).emit('friends:changed', { kind: 'accepted', user: pub(getUser(me)) });
    io.to('u' + me).emit('friends:changed', {});
    push(other, { title: 'Solicitação aceita', body: getUser(me).name + ' aceitou sua solicitação', tag: 'fa' + me });
  }
  return r.changes;
}
api.post('/friends/request', (req, res) => {
  const id = +req.body.id, o = getUser(id);
  if (!o || id === req.uid) return res.status(400).json({ error: 'Usuário inválido' });
  if (db.prepare('SELECT 1 FROM blocks WHERE user_id=? AND blocked_id=?').get(id, req.uid)) return res.status(403).json({ error: 'Não foi possível enviar a solicitação' });
  const ex = db.prepare('SELECT * FROM friendships WHERE (requester=? AND addressee=?) OR (requester=? AND addressee=?)').get(req.uid, id, id, req.uid);
  if (ex) {
    if (ex.status === 'pending' && ex.requester === id) { acceptFriend(req.uid, id); return res.json({ ok: true, accepted: true }); }
    return res.status(409).json({ error: ex.status === 'accepted' ? 'Vocês já são amigos' : 'Solicitação já enviada' });
  }
  db.prepare("INSERT INTO friendships(requester,addressee,status,created) VALUES(?,?,'pending',?)").run(req.uid, id, now());
  io.to('u' + id).emit('friends:changed', { kind: 'request', user: pub(req.user) });
  io.to('u' + req.uid).emit('friends:changed', {});
  push(id, { title: 'Nova solicitação de amizade', body: req.user.name + ' quer ser seu amigo', tag: 'fr' + req.uid });
  res.json({ ok: true });
});
api.post('/friends/accept', (req, res) => {
  if (!acceptFriend(req.uid, +req.body.id)) return res.status(404).json({ error: 'Solicitação não encontrada' });
  res.json({ ok: true });
});
api.delete('/friends/:id', (req, res) => {
  const id = +req.params.id;
  db.prepare('DELETE FROM friendships WHERE (requester=? AND addressee=?) OR (requester=? AND addressee=?)').run(req.uid, id, id, req.uid);
  db.prepare('DELETE FROM favorites WHERE (user_id=? AND friend_id=?) OR (user_id=? AND friend_id=?)').run(req.uid, id, id, req.uid);
  io.to('u' + id).emit('friends:changed', { kind: 'removed' });
  io.to('u' + req.uid).emit('friends:changed', {});
  res.json({ ok: true });
});
api.post('/favorites/:id', (req, res) => {
  const id = +req.params.id;
  if (!areFriends(req.uid, id)) return res.status(403).json({ error: 'Sem acesso' });
  const had = db.prepare('DELETE FROM favorites WHERE user_id=? AND friend_id=?').run(req.uid, id).changes;
  if (!had) db.prepare('INSERT INTO favorites(user_id,friend_id) VALUES(?,?)').run(req.uid, id);
  res.json({ fav: !had });
});
api.get('/blocks', (req, res) => res.json(db.prepare('SELECT u.id,u.handle,u.name,u.avatar FROM blocks b JOIN users u ON u.id=b.blocked_id WHERE b.user_id=?').all(req.uid)));
api.post('/blocks/:id', (req, res) => {
  const id = +req.params.id;
  if (!getUser(id) || id === req.uid) return res.status(400).json({ error: 'Usuário inválido' });
  db.prepare('INSERT OR IGNORE INTO blocks(user_id,blocked_id) VALUES(?,?)').run(req.uid, id);
  res.json({ ok: true });
});
api.delete('/blocks/:id', (req, res) => {
  db.prepare('DELETE FROM blocks WHERE user_id=? AND blocked_id=?').run(req.uid, +req.params.id);
  res.json({ ok: true });
});

/* ---------- mensagens e chamadas (histórico) ---------- */
api.get('/messages/:id', (req, res) => {
  const id = +req.params.id;
  if (!areFriends(req.uid, id)) return res.status(403).json({ error: 'Sem acesso' });
  const rows = db.prepare('SELECT * FROM (SELECT * FROM messages WHERE (from_id=? AND to_id=?) OR (from_id=? AND to_id=?) ORDER BY id DESC LIMIT 200) ORDER BY id').all(req.uid, id, id, req.uid);
  res.json(rows.map(msgOut));
});
api.get('/conversations', (req, res) => {
  const u = req.uid;
  const rows = db.prepare(`SELECT u.id,u.name,u.handle,u.avatar,m.body,m.type,m.created,m.deleted,m.from_id,
    (SELECT COUNT(*) FROM messages x WHERE x.from_id=u.id AND x.to_id=? AND x.status<2 AND x.deleted=0) unread
    FROM users u JOIN messages m ON m.id=(SELECT MAX(id) FROM messages WHERE (from_id=? AND to_id=u.id) OR (from_id=u.id AND to_id=?))
    WHERE u.id IN (SELECT CASE WHEN requester=? THEN addressee ELSE requester END FROM friendships WHERE status='accepted' AND (requester=? OR addressee=?))
    ORDER BY m.id DESC`).all(u, u, u, u, u, u);
  res.json(rows.map(r => ({ ...r, body: r.deleted ? null : r.body })));
});
api.get('/calls', (req, res) => {
  const rows = db.prepare(`SELECT c.id,c.video,c.started,c.status,c.caller,u.id pid,u.name pname,u.handle phandle,u.avatar pavatar
    FROM calls c JOIN users u ON u.id=CASE WHEN c.caller=? THEN c.callee ELSE c.caller END
    WHERE c.caller=? OR c.callee=? ORDER BY c.id DESC LIMIT 60`).all(req.uid, req.uid, req.uid);
  res.json(rows.map(r => ({ id: r.id, out: r.caller === req.uid, video: !!r.video, started: r.started, status: r.status,
    peer: { id: r.pid, name: r.pname, handle: r.phandle, avatar: r.pavatar } })));
});

app.use((err, req, res, next) => {
  res.status(400).json({ error: err.code === 'LIMIT_FILE_SIZE' ? 'Arquivo muito grande (máx. 50 MB)' : 'Requisição inválida' });
});

/* ---------- tempo real ---------- */
const rooms = new Map(); // room -> {id, video, members: Map(sid->uid), timers: Map(uid->timeout), startedAt}
io.use((s, next) => {
  try { s.uid = jwt.verify(String(s.handshake.auth.token || ''), SECRET).id; if (!getUser(s.uid)) throw new Error('x'); next(); }
  catch { next(new Error('auth')); }
});
const A = f => function (d, ack) {
  ack = typeof ack === 'function' ? ack : () => { };
  try { f.call(this, d || {}, ack); } catch (e) { console.error(e); ack({ error: 'Erro no servidor' }); }
};
const memberUids = r => [...r.members.values()];
const roomInfo = r => memberUids(r).map(u => pub(getUser(u)));

function missed(r, uid) {
  clearTimeout(r.timers.get(uid)); r.timers.delete(uid);
  const caller = r.caller;
  db.prepare("UPDATE calls SET status='missed' WHERE room=? AND callee=? AND status='ringing'").run(r.id, uid);
  io.to('u' + uid).emit('call:cancel', { room: r.id, missed: true, from: pub(getUser(caller)) });
  push(uid, { title: 'Chamada perdida', body: 'de ' + getUser(caller).name, tag: 'call' + r.id });
}
function checkEnd(r) {
  if (r.members.size === 0) for (const u of [...r.timers.keys()]) missed(r, u);
  if (r.members.size <= 1 && r.timers.size === 0) {
    io.to(r.id).emit('call:ended', { room: r.id });
    for (const sid of r.members.keys()) { const so = io.sockets.sockets.get(sid); if (so) { so.leave(r.id); so.room = null; } }
    rooms.delete(r.id);
  }
}
function leaveRoom(s) {
  const r = rooms.get(s.room);
  if (!r) return;
  r.members.delete(s.id); s.leave(r.id); s.room = null;
  io.to(r.id).emit('call:left', { sid: s.id, user: s.uid });
  checkEnd(r);
}

io.on('connection', s => {
  const uid = s.uid;
  s.join('u' + uid);
  if (io.sockets.adapter.rooms.get('u' + uid).size === 1) emitToFriends(uid, 'presence', { id: uid, online: true });
  // entrega mensagens pendentes
  const pend = db.prepare('SELECT DISTINCT from_id FROM messages WHERE to_id=? AND status=0').all(uid);
  if (pend.length) {
    db.prepare('UPDATE messages SET status=1 WHERE to_id=? AND status=0').run(uid);
    pend.forEach(p => io.to('u' + p.from_id).emit('msg:status', { peer: uid, status: 1, upTo: 9e15 }));
  }
  // chamadas tocando para este usuário
  for (const r of rooms.values()) if (r.timers.has(uid)) s.emit('call:incoming', { room: r.id, from: pub(getUser(r.caller)), video: r.video, members: roomInfo(r) });

  let last = 0;
  s.on('msg:send', A((d, ack) => {
    if (now() - last < 120) return ack({ error: 'Calma, muito rápido' });
    last = now();
    const to = +d.to;
    if (!to || !areFriends(uid, to) || blockedEither(uid, to)) return ack({ error: 'Não é possível enviar para este contato' });
    const type = ['text', 'image', 'video', 'audio', 'file'].includes(d.type) ? d.type : 'text';
    const body = String(d.body || '').slice(0, 4000);
    const url = d.url ? String(d.url) : null;
    if (url && !FILE_URL.test(url)) return ack({ error: 'Arquivo inválido' });
    if (type === 'text' ? !body.trim() : !url) return ack({ error: 'Mensagem vazia' });
    let reply = d.replyTo ? +d.replyTo : null;
    if (reply && !db.prepare('SELECT 1 FROM messages WHERE id=? AND ((from_id=? AND to_id=?) OR (from_id=? AND to_id=?))').get(reply, uid, to, to, uid)) reply = null;
    const delivered = isOnline(to);
    const info = db.prepare('INSERT INTO messages(from_id,to_id,type,body,url,fname,reply_to,status,created) VALUES(?,?,?,?,?,?,?,?,?)')
      .run(uid, to, type, body, url, d.fname ? String(d.fname).slice(0, 120) : null, reply, delivered ? 1 : 0, now());
    const m = db.prepare('SELECT * FROM messages WHERE id=?').get(info.lastInsertRowid);
    io.to('u' + to).emit('msg:new', m);
    s.to('u' + uid).emit('msg:new', m);
    ack({ ok: true, msg: m });
    if (!delivered) {
      const label = { text: body, image: '📷 Foto', video: '🎬 Vídeo', audio: '🎤 Áudio', file: '📎 ' + (d.fname || 'Documento') }[type];
      push(to, { kind: 'msg', title: getUser(uid).name, body: label.slice(0, 120), tag: 'msg' + uid, peer: uid });
    }
  }));
  s.on('msg:read', A(d => {
    const peer = +d.peer;
    const r = db.prepare('UPDATE messages SET status=2 WHERE from_id=? AND to_id=? AND status<2').run(peer, uid);
    if (r.changes) io.to('u' + peer).emit('msg:status', { peer: uid, status: 2, upTo: 9e15 });
    s.to('u' + uid).emit('msg:read-sync', { peer });
  }));
  s.on('msg:delete', A(d => {
    const m = db.prepare('SELECT * FROM messages WHERE id=? AND from_id=?').get(+d.id, uid);
    if (!m || m.deleted) return;
    db.prepare('UPDATE messages SET deleted=1, body=NULL, url=NULL, fname=NULL WHERE id=?').run(m.id);
    if (m.url && FILE_URL.test(m.url)) fs.unlink(path.join(uploadDir, path.basename(m.url)), () => { });
    io.to('u' + uid).to('u' + m.to_id).emit('msg:deleted', { id: m.id });
  }));

  /* chamadas */
  s.on('call:invite', A((d, ack) => {
    const to = +d.to;
    if (!to || !areFriends(uid, to) || blockedEither(uid, to)) return ack({ error: 'Não é possível ligar para este contato' });
    let r = d.room ? rooms.get(d.room) : null;
    if (d.room && (!r || s.room !== r.id)) return ack({ error: 'Chamada não encontrada' });
    if (!r) {
      r = { id: crypto.randomUUID(), video: !!d.video, caller: uid, members: new Map(), timers: new Map(), startedAt: null };
      rooms.set(r.id, r); r.members.set(s.id, uid); s.join(r.id); s.room = r.id;
    }
    if (memberUids(r).includes(to) || r.timers.has(to)) return ack({ error: 'Esse contato já está na chamada' });
    db.prepare("INSERT INTO calls(room,caller,callee,video,started,status) VALUES(?,?,?,?,?,'ringing')").run(r.id, uid, to, r.video ? 1 : 0, now());
    io.to('u' + to).emit('call:incoming', { room: r.id, from: pub(getUser(uid)), video: r.video, members: roomInfo(r) });
    push(to, { title: 'Chamada de ' + getUser(uid).name, body: r.video ? 'Chamada de vídeo' : 'Chamada de áudio', tag: 'call' + r.id, call: true, peer: uid });
    r.timers.set(to, setTimeout(() => {
      if (!r.timers.has(to)) return;
      missed(r, to);
      io.to(r.id).emit('call:noanswer', { user: to, name: getUser(to).name });
      checkEnd(r);
    }, 40000));
    ack({ ok: true, room: r.id });
  }));
  s.on('call:accept', A((d, ack) => {
    const r = rooms.get(d.room);
    if (!r || !r.timers.has(uid)) return ack({ error: 'Chamada não está mais disponível' });
    if (s.room) leaveRoom(s);
    clearTimeout(r.timers.get(uid)); r.timers.delete(uid);
    db.prepare("UPDATE calls SET status='answered' WHERE room=? AND callee=? AND status='ringing'").run(r.id, uid);
    if (!r.startedAt) r.startedAt = now();
    const peers = [...r.members.entries()].map(([sid, u]) => ({ sid, user: pub(getUser(u)) }));
    r.members.set(s.id, uid); s.join(r.id); s.room = r.id;
    s.to('u' + uid).emit('call:cancel', { room: r.id });
    s.to(r.id).emit('call:joined', { sid: s.id, user: pub(getUser(uid)), startedAt: r.startedAt });
    ack({ ok: true, peers, startedAt: r.startedAt, video: r.video });
  }));
  s.on('call:decline', A(d => {
    const r = rooms.get(d.room);
    if (!r || !r.timers.has(uid)) return;
    clearTimeout(r.timers.get(uid)); r.timers.delete(uid);
    db.prepare("UPDATE calls SET status='declined' WHERE room=? AND callee=? AND status='ringing'").run(r.id, uid);
    s.to('u' + uid).emit('call:cancel', { room: r.id });
    io.to(r.id).emit('call:declined', { user: uid, name: getUser(uid).name });
    checkEnd(r);
  }));
  s.on('call:signal', A(d => {
    const t = io.sockets.sockets.get(String(d.to));
    if (!t || !s.room || t.room !== s.room) return;
    t.emit('call:signal', { from: s.id, user: pub(getUser(uid)), data: d.data });
  }));
  s.on('call:state', A(d => { if (s.room) s.to(s.room).emit('call:state', { sid: s.id, cam: !!d.cam, mic: !!d.mic }); }));
  s.on('call:leave', A(() => leaveRoom(s)));

  s.on('disconnect', () => {
    leaveRoom(s);
    if (!isOnline(uid)) {
      db.prepare('UPDATE users SET last_seen=? WHERE id=?').run(now(), uid);
      emitToFriends(uid, 'presence', { id: uid, online: false });
    }
  });
});

const PORT = +process.env.PORT || 3000;
server.listen(PORT, () => console.log('DarkCall rodando na porta ' + PORT));
