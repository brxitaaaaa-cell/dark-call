# DarkCall
**Sua conexão. Seu espaço. Suas chamadas.** — Desenvolvedor: Adryel W.F

App de chamadas (áudio/vídeo, individual e em grupo), mensagens e amigos, em tempo real.
Funciona no navegador e instala como app (PWA) no Android e no computador.

**Stack:** Node.js + Express + Socket.IO (sinalização e mensagens) · SQLite · WebRTC (malha, STUN/TURN) · Web Push · front-end em JavaScript puro.

## 1. Testar no computador (2 minutos)
Requer Node.js 18 ou superior.
```bash
npm install
cp .env.example .env
npm start
```
Abra http://localhost:3000, crie duas contas (uma em cada navegador/aba anônima), adicione-se como amigos e ligue.

## 2. Usar no celular e pela internet (HTTPS é obrigatório)
Câmera, microfone e instalação como app só funcionam em HTTPS. Escolha uma opção:

**Teste rápido:** com o servidor rodando, use um túnel, por exemplo `cloudflared tunnel --url http://localhost:3000`, e abra o endereço https que ele mostrar no celular.

**Produção (VPS com domínio apontado para o IP):**
```bash
cp .env.example .env     # preencha DOMAIN, TURN_URL=turn:SEUDOMINIO:3478, TURN_SECRET (texto longo aleatório)
docker compose up -d --build
```
Isso sobe o app, HTTPS automático (Caddy) e o servidor TURN (coturn). Libere no firewall: 80, 443, 3478 (TCP/UDP) e 49160-49200 (UDP).
O TURN é o que faz as chamadas funcionarem entre redes de operadora e Wi-Fi com NAT restrito.

## 3. Notificações com o app fechado
```bash
npm run vapid
```
Copie as duas chaves para `VAPID_PUBLIC` e `VAPID_PRIVATE` no `.env` e reinicie. Cada usuário ativa em Configurações → Notificações do sistema.

## 4. Instalar como app
- **Android (Chrome):** menu ⋮ → "Instalar app".
- **Computador (Chrome/Edge):** ícone de instalar na barra de endereço.
- **iPhone:** Safari → Compartilhar → "Adicionar à Tela de Início" (iOS 16.4+ para notificações).

## 5. APK Android (opcional)
```bash
npm i @capacitor/core @capacitor/cli @capacitor/android
npx cap init DarkCall com.adryel.darkcall --web-dir=public
# em capacitor.config.json adicione: "server": { "url": "https://SEUDOMINIO" }
npx cap add android && npx cap open android
```

## Limites conhecidos
- **Bolha flutuante fora do app:** navegadores não podem desenhar sobre outros apps. Aqui existem a bolha arrastável dentro do DarkCall e o Picture-in-Picture do navegador (Configurações → Janela flutuante). A bolha do sistema no Android exige um plugin nativo com a permissão "Sobrepor a outros apps" (no APK via Capacitor).
- **Grupos:** chamadas em malha funcionam bem até cerca de 4-6 pessoas. Para salas maiores troque por um SFU (ex.: LiveKit).
- **Compartilhar tela:** não existe no Chrome do celular; funciona no computador.
- **Segurança:** senhas com bcrypt, login com JWT de 90 dias, limite de tentativas de login, CSP restritiva, uploads com nomes aleatórios (SVG/HTML bloqueados), TURN com credenciais temporárias. Faça backup da pasta `data/`.
