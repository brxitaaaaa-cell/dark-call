'use strict';
/* DarkCall — Desenvolvedor: Adryel W.F */
const $ = (s, e = document) => e.querySelector(s);
function h(tag, a, ...kids) {
  const e = document.createElement(tag);
  for (const k in a || {}) {
    const v = a[k];
    if (v == null || v === false) continue;
    if (k === 'class') e.className = v;
    else if (k === 'style' && typeof v === 'object') Object.assign(e.style, v);
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (k in e) e[k] = v;
    else e.setAttribute(k, v === true ? '' : v);
  }
  for (const c of kids.flat(2)) if (c != null && c !== false) e.append(c.nodeType ? c : document.createTextNode(c));
  return e;
}
const P = {
  home: '<path d="M3 11l9-8 9 8v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>',
  users: '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
  msg: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
  phone: '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.8 19.8 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/>',
  user: '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
  sliders: '<path d="M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12M20 18h0"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/>',
  mic: '<rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v4"/>',
  micoff: '<rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v4M2 2l20 20"/>',
  video: '<rect x="2" y="6" width="13" height="12" rx="2"/><path d="M22 8l-7 4 7 4z"/>',
  videooff: '<rect x="2" y="6" width="13" height="12" rx="2"/><path d="M22 8l-7 4 7 4zM2 2l20 20"/>',
  screen: '<rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  send: '<path d="M22 2L11 13M22 2l-7 20-4-9-9-4z"/>',
  clip: '<path d="M21 12.5l-8.5 8.5a5.5 5.5 0 0 1-8-8l9-9a3.5 3.5 0 0 1 5 5l-9 9a1.5 1.5 0 0 1-2-2l8-8"/>',
  star: '<path d="M12 2l3 6.9 7.5.7-5.7 5 1.7 7.4L12 18l-6.5 4 1.7-7.4-5.7-5 7.5-.7z"/>',
  x: '<path d="M18 6L6 18M6 6l12 12"/>',
  min: '<path d="M4 14h6v6M20 10h-6V4M14 10l7-7M3 21l7-7"/>',
  pip: '<rect x="2" y="4" width="20" height="14" rx="2"/><rect x="12" y="11" width="8" height="5" rx="1"/>',
  reply: '<path d="M9 14L4 9l5-5"/><path d="M20 20v-7a4 4 0 0 0-4-4H4"/>',
  trash: '<path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6"/>',
  bell: '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 0 1-3.4 0"/>',
  search: '<circle cx="11" cy="11" r="8"/><path d="M21 21l-4.3-4.3"/>',
  back: '<path d="M15 18l-6-6 6-6"/>',
  dots: '<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>'
};
const put = (el, ...k) => { for (const c of k.flat(2)) if (c != null && c !== false) el.append(c); };
const fill = (el, ...k) => el.replaceChildren(...k.flat(2).filter(c => c != null && c !== false));
const ic = (n, c = '') => { const s = h('span', { class: 'ic ' + c }); s.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${P[n]}</svg>`; return s; };

const DEF = { ringtone: 'neon', msgSound: 'pop', volume: 70, vibrate: true, silent: false, float: true, preview: 'all', notifyOnline: false };
const S = { token: localStorage.getItem('dc_token'), me: null, friends: [], convs: [], calls: [], msgs: {}, unread: {}, tab: 'home', chat: null,
  settings: { ...DEF }, ice: [{ urls: 'stun:stun.l.google.com:19302' }], vapid: null, reply: null, sock: null, incoming: null, blocks: [] };

const avatar = (u, c = '') => h('div', { class: 'av ' + c }, u.avatar ? h('img', { src: u.avatar, alt: '' }) : (u.name || '?').trim().slice(0, 2).toUpperCase());
const hm = t => new Date(t).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
const dayLabel = t => { const d = new Date(t), n = new Date(); return d.toDateString() === n.toDateString() ? hm(t) : d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }); };
const fmtDur = ms => { const s = Math.max(0, Math.floor(ms / 1000)), m = Math.floor(s / 60); return String(Math.floor(m / 60) ? Math.floor(m / 60) + ':' + String(m % 60).padStart(2, '0') : m).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0'); };
function toast(t) { const e = h('div', { class: 'toast' }, t); $('#toasts').append(e); setTimeout(() => e.remove(), 3500); }
function modal(title, body, btns = [['OK', null, 'pri']]) {
  const o = h('div', { class: 'overlay', onclick: e => e.target === o && o.remove() },
    h('div', { class: 'modal' }, h('h3', {}, title), typeof body === 'string' ? h('p', { class: 'mut' }, body) : body,
      h('div', { class: 'row end' }, btns.map(([t, fn, cls]) => h('button', { class: 'btn ' + (cls || ''), onclick: () => { o.remove(); fn && fn(); } }, t)))));
  document.body.append(o); return o;
}
function permHelp(what, e) {
  if (!window.isSecureContext) return modal('Conexão não segura', 'Chamadas e mídia só funcionam em páginas HTTPS (ou localhost). Abra o DarkCall pelo endereço https.');
  if (e && e.name === 'NotFoundError') return modal('Dispositivo não encontrado', `Não encontramos ${what} neste aparelho. Conecte um e tente de novo.`);
  if (e && !['NotAllowedError', 'SecurityError', 'PermissionDeniedError'].includes(e.name)) return toast('Erro: ' + (e.name || e.message));
  modal('Permissão necessária', `O DarkCall precisa de acesso a ${what} para fazer isto. Toque no cadeado ao lado do endereço do site, abra Permissões e permita o acesso. No app Android: Configurações do aparelho → Apps → DarkCall → Permissões.`);
}
async function API(m, u, b) {
  const o = { method: m, headers: {} };
  if (S.token) o.headers.Authorization = 'Bearer ' + S.token;
  if (b instanceof FormData) o.body = b; else if (b) { o.headers['Content-Type'] = 'application/json'; o.body = JSON.stringify(b); }
  const r = await fetch(u, o);
  const j = await r.json().catch(() => ({}));
  if (r.status === 401 && S.token) { logout(); throw new Error('Sessão expirada'); }
  if (!r.ok) throw new Error(j.error || 'Erro');
  return j;
}
const emit = (ev, d) => new Promise(res => S.sock.timeout(10000).emit(ev, d, (err, r) => res(err ? { error: 'Tempo esgotado' } : (r || {}))));
const upload = f => { const fd = new FormData(); fd.append('file', f); return API('POST', '/api/upload', fd); };

/* ---------- sons ---------- */
let AC; const ac = () => AC || (AC = new (window.AudioContext || window.webkitAudioContext)());
document.addEventListener('pointerdown', () => { try { ac().resume(); } catch (_) { } });
function tone(f, t0, d, type = 'sine', g = .3) {
  const c = ac(), o = c.createOscillator(), v = c.createGain(), t = c.currentTime + t0, vol = S.settings.volume / 100 * g;
  o.type = type; o.frequency.value = f;
  v.gain.setValueAtTime(0.0001, t); v.gain.linearRampToValueAtTime(Math.max(vol, .0002), t + .02); v.gain.exponentialRampToValueAtTime(.0001, t + d);
  o.connect(v).connect(c.destination); o.start(t); o.stop(t + d + .05);
}
const RING = { neon: [[880, 0, .15], [1175, .18, .15], [1568, .36, .3], [1175, .9, .15], [1568, 1.08, .3]],
  pulse: [[660, 0, .2, 'square', .15], [660, .3, .2, 'square', .15], [990, .6, .4, 'square', .15]],
  orbit: [[523, 0, .25, 'triangle'], [659, .25, .25, 'triangle'], [784, .5, .25, 'triangle'], [1047, .75, .5, 'triangle']] };
const MSGS = { pop: [[1200, 0, .08], [1600, .07, .1]], drop: [[900, 0, .12], [600, .1, .15]], ping: [[1760, 0, .2]] };
const seq = a => { try { a.forEach(n => tone(...n)); } catch (_) { } };
const msgSound = () => { if (!S.settings.silent) { seq(MSGS[S.settings.msgSound] || MSGS.pop); if (S.settings.vibrate && navigator.vibrate) navigator.vibrate(120); } };
const sendSound = () => { if (!S.settings.silent) seq([[1000, 0, .06, 'sine', .15], [1500, .05, .08, 'sine', .15]]); };
let ringT = null;
function startRing() {
  stopRing(); if (S.settings.silent) return;
  const play = () => { seq(RING[S.settings.ringtone] || RING.neon); if (S.settings.vibrate && navigator.vibrate) navigator.vibrate([400, 200, 400]); };
  play(); ringT = setInterval(play, 2400);
}
function stopRing() { clearInterval(ringT); ringT = null; if (navigator.vibrate) navigator.vibrate(0); }

/* ---------- notificações ---------- */
async function notify(title, body, tag, data) {
  if (!document.hidden || !('Notification' in window) || Notification.permission !== 'granted') return;
  const opts = { body, tag, icon: '/icon-192.png', badge: '/icon-192.png', data: data || {}, silent: S.settings.silent };
  try { const reg = await navigator.serviceWorker.ready; reg.showNotification(title, opts); } catch (_) { new Notification(title, opts); }
}
const b64u = s => { const p = '='.repeat((4 - s.length % 4) % 4), r = atob((s + p).replace(/-/g, '+').replace(/_/g, '/')); return Uint8Array.from([...r].map(c => c.charCodeAt(0))); };
async function enableNotifs() {
  if (!('Notification' in window)) return toast('Este navegador não suporta notificações');
  const p = await Notification.requestPermission();
  if (p !== 'granted') return permHelp('notificações');
  try {
    if (S.vapid) { const reg = await navigator.serviceWorker.ready; const sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64u(S.vapid) }); await API('POST', '/api/push', sub.toJSON()); }
    toast('Notificações ativadas'); renderTab();
  } catch (e) { toast('Não foi possível ativar o push: ' + e.message); }
}
const previewOf = m => ({ text: m.body, image: '📷 Foto', video: '🎬 Vídeo', audio: '🎤 Áudio', file: '📎 ' + (m.fname || 'Documento') }[m.type] || '');

/* ---------- boot / telas de entrada ---------- */
function setToken(t) { S.token = t; localStorage.setItem('dc_token', t); }
function logout() {
  localStorage.removeItem('dc_token'); S.token = null; if (S.sock) S.sock.close();
  navigator.serviceWorker?.ready.then(r => r.pushManager.getSubscription()).then(s => s && s.unsubscribe()).catch(() => { });
  location.reload();
}
function splash() {
  const logo = h('div', { class: 'logo' }, [...'DarkCall'].map((c, i) => h('span', { style: { animationDelay: i * 70 + 'ms,' + (700 + i * 90) + 'ms' } }, c)));
  $('#app').replaceChildren(h('div', { class: 'splash' }, h('div', { class: 'dev' }, 'Desenvolvedor: Adryel W.F.'), logo,
    h('p', { class: 'slogan' }, 'Sua conexão. Seu espaço. Suas chamadas.'),
    h('button', { class: 'btn pri', onclick: () => { localStorage.setItem('dc_seen', '1'); authScreen(); } }, 'Começar')));
}
function authScreen(mode = 'login') {
  const reg = mode === 'register';
  const err = h('div', { class: 'err' });
  const handle = h('input', { class: 'f', placeholder: 'ID (ex: adryel_01)', autocapitalize: 'none', autocomplete: 'username', maxLength: 20 });
  const name = h('input', { class: 'f', placeholder: 'Seu nome', maxLength: 40 });
  const pass = h('input', { class: 'f', type: 'password', placeholder: 'Senha (mínimo 8 caracteres)', autocomplete: reg ? 'new-password' : 'current-password' });
  const photo = h('input', { type: 'file', accept: 'image/*', class: 'f' });
  const go = h('button', { class: 'btn pri', type: 'submit' }, reg ? 'Criar conta' : 'Entrar');
  const form = h('form', {
    onsubmit: async e => {
      e.preventDefault(); err.textContent = ''; go.disabled = true;
      try {
        const r = await API('POST', reg ? '/api/register' : '/api/login', { handle: handle.value, name: name.value, password: pass.value });
        setToken(r.token);
        if (reg && photo.files[0]) { try { const up = await upload(photo.files[0]); await API('PUT', '/api/me', { avatar: up.url }); } catch (_) { } }
        await start();
      } catch (x) { err.textContent = x.message; go.disabled = false; }
    }
  }, h('div', { class: 'tabs2' }, h('button', { type: 'button', class: reg ? '' : 'on', onclick: () => authScreen('login') }, 'Entrar'), h('button', { type: 'button', class: reg ? 'on' : '', onclick: () => authScreen('register') }, 'Cadastrar')),
    reg ? name : null, handle, pass, reg ? h('label', { class: 'mut' }, 'Foto de perfil (opcional)', photo) : null, err, go);
  $('#app').replaceChildren(h('div', { class: 'auth' }, h('div', { class: 'logo', style: { fontSize: '44px' } }, h('span', {}, 'Dark'), h('span', { style: { color: 'var(--neon)' } }, 'Call')), form));
}
async function boot() {
  navigator.serviceWorker?.register('/sw.js').catch(() => { });
  navigator.serviceWorker?.addEventListener('message', e => { const d = e.data && e.data.open; if (d && d.peer) openChat(+d.peer); });
  if (S.token) { try { await start(); return; } catch (_) { localStorage.removeItem('dc_token'); S.token = null; } }
  localStorage.getItem('dc_seen') ? authScreen() : splash();
}
async function start() {
  S.me = await API('GET', '/api/me');
  S.settings = { ...DEF, ...S.me.settings };
  const cfg = await API('GET', '/api/config'); S.ice = cfg.ice; S.vapid = cfg.vapid;
  connect();
  await Promise.all([loadFriends(true), loadConvs(true), loadCalls(true)]);
  S.tab = 'home'; shell();
}

/* ---------- dados ---------- */
async function loadFriends(quiet) { S.friends = await API('GET', '/api/friends'); if (!quiet) { drawNav(); if (!S.chat && ['home', 'friends'].includes(S.tab)) renderTab(); } }
async function loadConvs(quiet) {
  S.convs = await API('GET', '/api/conversations');
  S.convs.forEach(c => { S.unread[c.id] = S.chat === c.id ? 0 : c.unread; });
  if (!quiet) { drawNav(); if (!S.chat && S.tab === 'msgs') renderTab(); }
}
async function loadCalls(quiet) { S.calls = await API('GET', '/api/calls'); if (!quiet && !S.chat && S.tab === 'calls') renderTab(); }
const friendOf = id => S.friends.find(f => f.id === id && f.status === 'accepted');

/* ---------- socket ---------- */
function connect() {
  const s = S.sock = io({ auth: { token: S.token } });
  s.on('connect_error', e => { if (e.message === 'auth') logout(); });
  s.on('disconnect', () => toast('Reconectando…'));
  s.on('connect', () => { if (S.me && S.friends.length) { loadFriends(); loadConvs(); if (S.chat) refreshChat(); } });
  s.on('msg:new', onMsg);
  s.on('msg:status', ({ peer, status, upTo }) => {
    (S.msgs[peer] || []).forEach(m => { if (m.from_id === S.me.id && m.status < status && m.id <= upTo) m.status = status; });
    if (S.chat === peer) drawMsgs();
  });
  s.on('msg:read-sync', ({ peer }) => { S.unread[peer] = 0; drawNav(); loadConvs(); });
  s.on('msg:deleted', ({ id }) => {
    for (const k in S.msgs) S.msgs[k].forEach(m => { if (m.id === id) { m.deleted = 1; m.body = m.url = m.fname = null; } });
    if (S.chat) drawMsgs(); loadConvs();
  });
  s.on('presence', ({ id, online }) => {
    const f = S.friends.find(x => x.id === id); if (!f) return;
    f.online = online; drawChatHead();
    if (online && S.settings.notifyOnline && f.status === 'accepted') { toast(f.name + ' está online'); notify(f.name, 'Ficou online', 'on' + id); }
    if (!S.chat && ['home', 'friends'].includes(S.tab)) renderTab();
  });
  s.on('friends:changed', async ({ kind, user }) => {
    await loadFriends();
    if (kind === 'request' && user) { toast(user.name + ' enviou uma solicitação de amizade'); msgSound(); notify('Nova solicitação de amizade', user.name, 'fr' + user.id); }
    if (kind === 'accepted' && user) { toast(user.name + ' aceitou sua solicitação'); msgSound(); notify('Solicitação aceita', user.name, 'fa' + user.id); }
  });
  s.on('call:incoming', onIncoming);
  s.on('call:cancel', ({ room, missed, from }) => {
    if (S.incoming && S.incoming.room === room) hideIncoming();
    if (missed) { toast('Chamada perdida' + (from ? ' de ' + from.name : '')); notify('Chamada perdida', from ? 'de ' + from.name : '', 'call' + room); loadCalls(); }
  });
  s.on('call:joined', onJoined);
  s.on('call:left', ({ sid, user }) => { if (!C) return; const p = C.peers.get(sid); if (p) { toast((p.user.name || 'Participante') + ' saiu'); dropPeer(sid); } });
  s.on('call:signal', onSignal);
  s.on('call:state', ({ sid, cam, mic }) => { const p = C && C.peers.get(sid); if (p) { p.cam = cam; p.mic = mic; updateTile(p); } });
  s.on('call:ended', ({ room }) => { if (C && C.room === room) { toast('Chamada encerrada'); endCall(false); } });
  s.on('call:declined', ({ name }) => toast(name + ' recusou a chamada'));
  s.on('call:noanswer', ({ name }) => toast(name + ' não atendeu'));
}
document.addEventListener('visibilitychange', () => { if (!document.hidden && S.chat && S.sock) S.sock.emit('msg:read', { peer: S.chat }); });

function onMsg(m) {
  const mine = m.from_id === S.me.id, peer = mine ? m.to_id : m.from_id;
  if (S.msgs[peer] && !S.msgs[peer].some(x => x.id === m.id)) S.msgs[peer].push(m);
  if (!mine) {
    const f = friendOf(peer);
    if (S.chat === peer && !document.hidden) S.sock.emit('msg:read', { peer });
    else {
      S.unread[peer] = (S.unread[peer] || 0) + 1; msgSound();
      if (document.hidden) {
        const pv = S.settings.preview;
        notify(pv === 'none' ? 'DarkCall' : (f ? f.name : 'Nova mensagem'), pv === 'all' ? previewOf(m) : 'Nova mensagem', 'msg' + peer, { peer });
      } else if (S.chat !== peer) toast((f ? f.name : 'Nova mensagem') + (S.settings.preview === 'all' ? ': ' + previewOf(m).slice(0, 50) : ''));
    }
  }
  if (S.chat === peer) drawMsgs();
  drawNav(); loadConvs();
}

/* ---------- layout ---------- */
const TABS = [['home', 'Início', 'home'], ['friends', 'Amigos', 'users'], ['msgs', 'Mensagens', 'msg'], ['calls', 'Chamadas', 'phone'], ['profile', 'Perfil', 'user'], ['settings', 'Config.', 'sliders']];
function shell() {
  $('#app').replaceChildren(h('div', { class: 'shell' }, h('nav', { id: 'nav' }), h('main', { id: 'content' })));
  drawNav(); renderTab();
}
function drawNav() {
  const n = $('#nav'); if (!n) return;
  const un = Object.values(S.unread).reduce((a, b) => a + b, 0), rq = S.friends.filter(f => f.status === 'pending' && f.incoming).length;
  fill(n, h('div', { class: 'brand' }, 'Dark', h('b', {}, 'Call')), TABS.map(([id, label, icon]) => {
    const b = { friends: rq, msgs: un }[id];
    return h('button', { class: S.tab === id ? 'on' : '', onclick: () => { S.tab = id; S.chat = null; drawNav(); renderTab(); } }, ic(icon), label, b ? h('span', { class: 'badge' }, b > 99 ? '99+' : b) : null);
  }));
}
function renderTab() {
  const c = $('#content'); if (!c) return;
  if (S.chat) return;
  const page = h('div', { class: 'page' });
  ({ home: homeTab, friends: friendsTab, msgs: msgsTab, calls: callsTab, profile: profileTab, settings: settingsTab })[S.tab](page);
  c.replaceChildren(page); c.scrollTop = 0;
}
const callBtns = f => f.blocked ? [h('span', { class: 'pill' }, 'bloqueado')] : [
  h('button', { class: 'ibtn', title: 'Ligar', onclick: () => startCall(f, false) }, ic('phone')),
  h('button', { class: 'ibtn', title: 'Vídeo', onclick: () => startCall(f, true) }, ic('video'))];
const peerRow = (f, extra = []) => h('div', { class: 'item' }, h('div', { class: 'avw' }, avatar(f), h('i', { class: 'dot ' + (f.online ? 'on' : '') })),
  h('div', { class: 'grow' }, h('b', {}, f.name), h('br'), h('small', {}, '@' + f.handle + (f.online ? ' · online' : ' · offline'))), extra);

function homeTab(p) {
  const acc = S.friends.filter(f => f.status === 'accepted'), on = acc.filter(f => f.online), rq = S.friends.filter(f => f.status === 'pending' && f.incoming);
  put(p, h('h2', {}, 'Olá, ' + S.me.name.split(' ')[0]),
    ('Notification' in window && Notification.permission === 'default') ? h('div', { class: 'card row' }, ic('bell'), h('div', { class: 'grow' }, 'Receba avisos de mensagens e chamadas'), h('button', { class: 'btn sm pri', onclick: enableNotifs }, 'Ativar')) : null,
    rq.length ? h('div', { class: 'card row' }, h('div', { class: 'grow' }, rq.length + ' solicitação(ões) de amizade'), h('button', { class: 'btn sm', onclick: () => { S.tab = 'friends'; drawNav(); renderTab(); } }, 'Ver')) : null,
    h('h4', {}, 'Amigos online (' + on.length + ')'),
    on.length ? h('div', { class: 'chips' }, on.map(f => h('div', { class: 'chip', onclick: () => openChat(f.id) }, h('div', { class: 'avw' }, avatar(f), h('i', { class: 'dot on' })), f.name.split(' ')[0]))) : h('p', { class: 'mut' }, acc.length ? 'Ninguém online agora.' : 'Adicione amigos na aba Amigos para começar.'),
    h('h4', {}, 'Chamadas recentes'),
    S.calls.length ? h('div', { class: 'card' }, S.calls.slice(0, 4).map(callRow)) : h('p', { class: 'mut' }, 'Nenhuma chamada ainda.'));
}
function friendsTab(p) {
  const res = h('div', {});
  let tm;
  const search = h('input', {
    class: 'f', placeholder: 'Buscar por nome ou ID', oninput: e => {
      clearTimeout(tm); const q = e.target.value.trim();
      tm = setTimeout(async () => {
        if (q.length < 2) return res.replaceChildren();
        try {
          const r = await API('GET', '/api/users/search?q=' + encodeURIComponent(q));
          res.replaceChildren(r.length ? h('div', { class: 'card' }, r.map(u => h('div', { class: 'item' }, avatar(u), h('div', { class: 'grow' }, h('b', {}, u.name), h('br'), h('small', {}, '@' + u.handle)),
            u.rel === 'friend' ? h('span', { class: 'pill' }, 'amigo') : u.rel === 'sent' ? h('span', { class: 'pill' }, 'enviada') :
              h('button', { class: 'btn sm pri', onclick: async ev => { try { await API('POST', '/api/friends/request', { id: u.id }); ev.target.replaceWith(h('span', { class: 'pill' }, u.rel === 'incoming' ? 'amigo' : 'enviada')); } catch (x) { toast(x.message); } } }, u.rel === 'incoming' ? 'Aceitar' : 'Adicionar')))) : h('p', { class: 'mut' }, 'Ninguém encontrado.'));
        } catch (x) { toast(x.message); }
      }, 300);
    }
  });
  const inc = S.friends.filter(f => f.status === 'pending' && f.incoming), sent = S.friends.filter(f => f.status === 'pending' && !f.incoming), acc = S.friends.filter(f => f.status === 'accepted');
  const fav = acc.filter(f => f.fav), on = acc.filter(f => !f.fav && f.online), off = acc.filter(f => !f.fav && !f.online);
  const row = f => peerRow(f, [
    h('button', { class: 'ibtn' + (f.fav ? ' fav' : ''), title: 'Favorito', onclick: async () => { await API('POST', '/api/favorites/' + f.id); loadFriends(); } }, ic('star')),
    f.blocked ? null : h('button', { class: 'ibtn', title: 'Mensagem', onclick: () => openChat(f.id) }, ic('msg')), callBtns(f),
    h('button', { class: 'ibtn', title: 'Mais', onclick: () => friendMenu(f) }, ic('dots'))]);
  const sec = (t, a, fn) => a.length ? [h('h4', {}, t), h('div', { class: 'card' }, a.map(fn))] : [];
  put(p, h('h2', {}, 'Amigos'), h('div', { class: 'row' }, ic('search'), search), res,
    sec('Solicitações recebidas', inc, f => peerRow(f, [h('button', { class: 'btn sm pri', onclick: async () => { await API('POST', '/api/friends/accept', { id: f.id }); loadFriends(); } }, 'Aceitar'), h('button', { class: 'btn sm', onclick: async () => { await API('DELETE', '/api/friends/' + f.id); loadFriends(); } }, 'Recusar')])),
    sec('Enviadas', sent, f => peerRow(f, [h('button', { class: 'btn sm', onclick: async () => { await API('DELETE', '/api/friends/' + f.id); loadFriends(); } }, 'Cancelar')])),
    sec('Favoritos', fav, row), sec('Online', on, row), sec('Offline', off, row),
    acc.length ? null : h('p', { class: 'mut' }, 'Busque pelo nome ou ID para adicionar seu primeiro amigo.'));
}
function friendMenu(f) {
  modal(f.name, '@' + f.handle, [['Fechar'],
    [f.blocked ? 'Desbloquear' : 'Bloquear', async () => { await API(f.blocked ? 'DELETE' : 'POST', '/api/blocks/' + f.id); loadFriends(); }],
    ['Remover amigo', () => modal('Remover amigo?', f.name + ' será removido da sua lista.', [['Cancelar'], ['Remover', async () => { await API('DELETE', '/api/friends/' + f.id); loadFriends(); loadConvs(); }, 'red']]), 'red']]);
}
function msgsTab(p) {
  put(p, h('h2', {}, 'Mensagens'), S.convs.length ? h('div', { class: 'card' }, S.convs.map(c => h('div', { class: 'item click', onclick: () => openChat(c.id) }, avatar(c),
    h('div', { class: 'grow' }, h('b', {}, c.name), h('br'), h('small', {}, c.deleted ? 'Mensagem apagada' : (c.from_id === S.me.id ? 'Você: ' : '') + previewOf(c).slice(0, 60))),
    h('div', { style: { textAlign: 'right' } }, h('small', {}, dayLabel(c.created)), S.unread[c.id] ? h('div', {}, h('span', { class: 'badge', style: { position: 'static', display: 'inline-block' } }, S.unread[c.id])) : null)))) :
    h('p', { class: 'mut' }, 'Nenhuma conversa. Toque no ícone de mensagem de um amigo na aba Amigos.'));
}
const ST = { answered: 'Atendida', missed: 'Perdida', declined: 'Recusada', ringing: 'Chamando' };
function callRow(c) {
  const f = friendOf(c.peer.id);
  return h('div', { class: 'item' }, avatar(c.peer), h('div', { class: 'grow' }, h('b', {}, c.peer.name), h('br'),
    h('small', { class: c.status === 'missed' && !c.out ? 'red-t' : '' }, (c.out ? 'Saída' : 'Recebida') + ' · ' + (c.video ? 'vídeo' : 'áudio') + ' · ' + ST[c.status] + ' · ' + dayLabel(c.started))),
    f && !f.blocked ? [h('button', { class: 'ibtn', onclick: () => startCall(f, false) }, ic('phone')), h('button', { class: 'ibtn', onclick: () => startCall(f, true) }, ic('video'))] : null);
}
function callsTab(p) { put(p, h('h2', {}, 'Chamadas'), S.calls.length ? h('div', { class: 'card' }, S.calls.map(callRow)) : h('p', { class: 'mut' }, 'Seu histórico de chamadas aparece aqui.')); }

function profileTab(p) {
  const file = h('input', { type: 'file', accept: 'image/*', hidden: true, onchange: async e => { if (!e.target.files[0]) return; try { const up = await upload(e.target.files[0]); S.me = await API('PUT', '/api/me', { avatar: up.url }); toast('Foto atualizada'); renderTab(); } catch (x) { toast(x.message); } } });
  const name = h('input', { class: 'f', value: S.me.name, maxLength: 40 });
  put(p, h('h2', {}, 'Perfil'), h('div', { class: 'card', style: { display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '12px' } },
    h('div', { onclick: () => file.click(), style: { cursor: 'pointer' } }, avatar(S.me, 'xxl')), file,
    h('button', { class: 'btn sm', onclick: () => file.click() }, 'Alterar foto'), h('small', {}, '@' + S.me.handle), name,
    h('button', { class: 'btn pri', onclick: async () => { try { S.me = await API('PUT', '/api/me', { name: name.value }); toast('Nome salvo'); } catch (x) { toast(x.message); } } }, 'Salvar nome')),
    h('div', { class: 'card' }, h('div', { class: 'item' }, h('div', { class: 'grow' }, 'Amigos'), h('b', {}, S.friends.filter(f => f.status === 'accepted').length)), h('div', { class: 'item' }, h('div', { class: 'grow' }, 'Chamadas'), h('b', {}, S.calls.length))),
    h('button', { class: 'btn red', onclick: () => modal('Sair da conta?', 'Você precisará entrar novamente.', [['Cancelar'], ['Sair', logout, 'red']]) }, 'Sair da conta'));
}
function settingsTab(p) {
  const set = (k, v) => { S.settings[k] = v; clearTimeout(S.st); S.st = setTimeout(() => API('PUT', '/api/me', { settings: S.settings }).catch(() => { }), 400); };
  const tog = (label, k, hint) => { const t = h('button', { class: 'toggle' + (S.settings[k] ? ' on' : ''), role: 'switch', onclick: () => { set(k, !S.settings[k]); t.classList.toggle('on', S.settings[k]); } }); return h('div', { class: 'item' }, h('div', { class: 'grow' }, label, hint ? h('br') : null, hint ? h('small', {}, hint) : null), t); };
  const sel = (label, k, opts, test) => h('div', { class: 'item' }, h('div', { class: 'grow' }, label), h('select', { class: 'f', style: { width: 'auto' }, onchange: e => { set(k, e.target.value); test && test(); } }, opts.map(([v, t]) => h('option', { value: v, selected: S.settings[k] === v }, t))));
  const blocks = h('div', {});
  API('GET', '/api/blocks').then(b => fill(blocks, b.length ? b.map(u => h('div', { class: 'item' }, avatar(u), h('div', { class: 'grow' }, u.name), h('button', { class: 'btn sm', onclick: async () => { await API('DELETE', '/api/blocks/' + u.id); loadFriends(); renderTab(); } }, 'Desbloquear'))) : h('small', {}, 'Nenhum contato bloqueado.'))).catch(() => { });
  const vol = h('input', { type: 'range', min: 0, max: 100, value: S.settings.volume, style: { width: '140px' }, onchange: e => { set('volume', +e.target.value); seq(MSGS.pop); } });
  put(p, h('h2', {}, 'Configurações'),
    h('h4', {}, 'Conta'), h('div', { class: 'card' }, h('div', { class: 'item click', onclick: () => { S.tab = 'profile'; drawNav(); renderTab(); } }, avatar(S.me), h('div', { class: 'grow' }, h('b', {}, S.me.name), h('br'), h('small', {}, 'Editar perfil, nome e foto')))),
    h('h4', {}, 'Privacidade'), h('div', { class: 'card' }, sel('Prévia nas notificações', 'preview', [['all', 'Nome e mensagem'], ['name', 'Só o nome'], ['none', 'Nada']]), tog('Avisar quando amigos ficarem online', 'notifyOnline')),
    h('h4', {}, 'Sons e notificações'), h('div', { class: 'card' },
      sel('Toque de chamada', 'ringtone', [['neon', 'Neon'], ['pulse', 'Pulso'], ['orbit', 'Órbita']], () => seq(RING[S.settings.ringtone])),
      sel('Som de mensagem', 'msgSound', [['pop', 'Pop'], ['drop', 'Gota'], ['ping', 'Ping']], () => seq(MSGS[S.settings.msgSound])),
      h('div', { class: 'item' }, h('div', { class: 'grow' }, 'Volume dos sons'), vol), tog('Vibração', 'vibrate'), tog('Modo silencioso', 'silent', 'Sem sons nem vibração'),
      h('div', { class: 'item' }, h('div', { class: 'grow' }, 'Notificações do sistema', h('br'), h('small', {}, 'Notification' in window ? ({ granted: 'Ativadas', denied: 'Bloqueadas no navegador', default: 'Desativadas' })[Notification.permission] : 'Não suportado')), h('button', { class: 'btn sm pri', onclick: enableNotifs }, 'Ativar'))),
    h('h4', {}, 'Janela flutuante'), h('div', { class: 'card' }, tog('Janela flutuante', 'float', 'Minimizar chamada em bolha e usar picture-in-picture')),
    h('h4', {}, 'Bloqueados'), h('div', { class: 'card' }, blocks),
    h('p', { class: 'mut' }, 'DarkCall · Desenvolvedor: Adryel W.F · Sua conexão. Seu espaço. Suas chamadas.'));
}

/* ---------- chat ---------- */
async function openChat(uid) {
  const f = friendOf(uid); if (!f) return;
  S.tab = 'msgs'; S.chat = uid; S.reply = null; drawNav();
  try { S.msgs[uid] = await API('GET', '/api/messages/' + uid); } catch (e) { S.chat = null; return toast(e.message); }
  buildChat(f);
  S.unread[uid] = 0; S.sock.emit('msg:read', { peer: uid }); drawNav();
}
async function refreshChat() { try { S.msgs[S.chat] = await API('GET', '/api/messages/' + S.chat); drawMsgs(); } catch (_) { } }
const linkify = t => String(t).split(/(https?:\/\/[^\s<]+)/g).map((s, i) => i % 2 ? h('a', { href: s, target: '_blank', rel: 'noopener noreferrer' }, s) : s);
function msgNode(m) {
  const mine = m.from_id === S.me.id, list = S.msgs[S.chat] || [];
  const b = h('div', { class: 'bubble' + (mine ? ' me' : '') });
  if (m.reply_to) { const r = list.find(x => x.id === m.reply_to); b.append(h('div', { class: 'quote' }, r ? (r.deleted ? 'Mensagem apagada' : previewOf(r).slice(0, 80)) : 'Mensagem')); }
  if (m.deleted) b.append(h('i', { class: 'del' }, 'Mensagem apagada'));
  else {
    if (m.type === 'image') b.append(h('img', { src: m.url, alt: '', loading: 'lazy', onclick: () => window.open(m.url, '_blank', 'noopener') }));
    else if (m.type === 'video') b.append(h('video', { src: m.url, controls: true, preload: 'metadata', playsInline: true }));
    else if (m.type === 'audio') b.append(h('audio', { src: m.url, controls: true, preload: 'metadata' }));
    else if (m.type === 'file') b.append(h('a', { href: m.url, download: m.fname || 'arquivo', target: '_blank', rel: 'noopener' }, '📎 ' + (m.fname || 'arquivo')));
    if (m.body) b.append(h('div', {}, linkify(m.body)));
  }
  const meta = h('div', { class: 'meta' }, hm(m.created));
  if (!m.deleted) {
    meta.append(h('button', { title: 'Responder', onclick: () => { S.reply = m; showReply(); $('#minp')?.focus(); } }, ic('reply')));
    if (mine) meta.append(h('button', { title: 'Apagar', onclick: () => modal('Apagar mensagem?', 'Ela será apagada para os dois.', [['Cancelar'], ['Apagar', () => S.sock.emit('msg:delete', { id: m.id }), 'red']]) }, ic('trash')));
  }
  if (mine && !m.deleted) meta.append(h('span', { class: 'tick t' + m.status, title: ['Enviada', 'Entregue', 'Visualizada'][m.status] }, m.status ? '✓✓' : '✓'));
  b.append(meta); return b;
}
function drawMsgs() {
  const box = $('#msgs'); if (!box) return;
  const atEnd = box.scrollHeight - box.scrollTop - box.clientHeight < 120 || !box.children.length;
  box.replaceChildren(...(S.msgs[S.chat] || []).map(msgNode));
  if (atEnd) box.scrollTop = box.scrollHeight;
}
function drawChatHead() {
  const el = $('#chead'); const f = friendOf(S.chat); if (!el || !f) return;
  fill(el, h('button', { class: 'ibtn', onclick: () => { S.chat = null; renderTab(); } }, ic('back')), h('div', { class: 'avw' }, avatar(f), h('i', { class: 'dot ' + (f.online ? 'on' : '') })),
    h('div', { class: 'grow' }, h('b', {}, f.name), h('br'), h('small', {}, f.online ? 'online' : 'offline')), callBtns(f));
}
function showReply() {
  const r = $('#replybar'); if (!r) return;
  r.classList.toggle('hidden', !S.reply);
  fill(r, ic('reply'), h('div', { class: 'grow mut' }, S.reply ? previewOf(S.reply).slice(0, 80) : ''), h('button', { class: 'ibtn', onclick: () => { S.reply = null; showReply(); } }, ic('x')));
}
async function sendMsg(to, type, body, file) {
  const r = await emit('msg:send', { to, type, body, url: file && file.url, fname: file && file.name, replyTo: S.reply && S.reply.id });
  if (r.error) return toast(r.error);
  S.reply = null; showReply();
  const l = S.msgs[to] || (S.msgs[to] = []); if (!l.some(x => x.id === r.msg.id)) l.push(r.msg);
  drawMsgs(); sendSound(); loadConvs();
}
async function attach(file, to) {
  toast('Enviando…');
  try {
    const t = file.type.startsWith('image/') && file.type !== 'image/svg+xml' ? 'image' : file.type.startsWith('video/') ? 'video' : file.type.startsWith('audio/') ? 'audio' : 'file';
    await sendMsg(to, t, '', await upload(file));
  } catch (e) { toast(e.message); }
}
let rec = null;
async function toggleRec(btn, to) {
  if (rec) { rec.stop(); return; }
  let st; try { st = await navigator.mediaDevices.getUserMedia({ audio: true }); } catch (e) { return permHelp('o microfone', e); }
  const chunks = []; const mr = rec = new MediaRecorder(st); btn.classList.add('rec');
  mr.ondataavailable = e => chunks.push(e.data);
  mr.onstop = async () => {
    st.getTracks().forEach(t => t.stop()); btn.classList.remove('rec'); rec = null;
    const mime = mr.mimeType || 'audio/webm', blob = new Blob(chunks, { type: mime });
    if (blob.size < 800) return;
    await attach(new File([blob], 'audio.' + (mime.includes('mp4') ? 'm4a' : mime.includes('ogg') ? 'ogg' : 'webm'), { type: mime }), to);
  };
  mr.start();
}
function buildChat(f) {
  const to = f.id;
  const inp = h('textarea', { id: 'minp', rows: 1, placeholder: 'Mensagem', maxLength: 4000, onkeydown: e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } }, oninput: () => { inp.style.height = 'auto'; inp.style.height = Math.min(inp.scrollHeight, 120) + 'px'; } });
  const file = h('input', { type: 'file', hidden: true, onchange: e => { if (e.target.files[0]) attach(e.target.files[0], to); e.target.value = ''; } });
  const mic = h('button', { class: 'ibtn', title: 'Gravar áudio', onclick: () => toggleRec(mic, to) }, ic('mic'));
  const send = () => { const t = inp.value.trim(); if (!t) return; inp.value = ''; inp.style.height = 'auto'; sendMsg(to, 'text', t); };
  $('#content').replaceChildren(h('div', { class: 'chat' }, h('header', { id: 'chead' }), h('div', { class: 'msgs', id: 'msgs' }), h('div', { class: 'replybar hidden', id: 'replybar' }),
    f.blocked ? h('div', { class: 'composer mut' }, 'Contato bloqueado. Desbloqueie em Configurações.') :
      h('div', { class: 'composer' }, h('button', { class: 'ibtn', title: 'Anexar', onclick: () => file.click() }, ic('clip')), file, inp, mic, h('button', { class: 'ibtn on', title: 'Enviar', onclick: send }, ic('send')))));
  drawChatHead(); drawMsgs(); showReply();
}

/* ---------- chamadas (WebRTC em malha) ---------- */
let C = null; // chamada ativa
async function getMedia(c, what) { try { return await navigator.mediaDevices.getUserMedia(c); } catch (e) { permHelp(what, e); throw e; } }
function newCall(local, video, room) {
  C = { room, video, local, peers: new Map(), tiles: new Map(), muted: false, cam: video, screen: null, startedAt: null, watchers: [], timer: null, ui: null };
  return C;
}
function tileEl(id, user, local) {
  const v = h('video', { autoplay: true, playsInline: true }); if (local) v.muted = true;
  const t = h('div', { class: 'tile novid' + (local ? ' local' : ''), 'data-id': id }, v, h('div', { class: 'tile-av' }, avatar(user, 'xl')), h('div', { class: 'tile-name' }, local ? 'Você' : user.name, h('span', { class: 'mi' })));
  C.tiles.set(id, t); $('.grid', C.ui).append(t); return t;
}
function watch(stream, tile) {
  try {
    const c = ac(), an = c.createAnalyser(); an.fftSize = 256; c.createMediaStreamSource(stream).connect(an);
    const buf = new Uint8Array(an.frequencyBinCount);
    C.watchers.push(setInterval(() => { an.getByteFrequencyData(buf); tile.classList.toggle('speaking', buf.reduce((a, b) => a + b, 0) / buf.length > 16); }, 150));
  } catch (_) { }
}
function showCallUI(title) {
  const ui = h('div', { class: 'call' },
    h('div', { class: 'call-top' }, h('div', {}, h('b', { class: 'call-title' }, title || 'Chamada'), h('small', { class: 'call-time' }, 'Chamando…')), h('small', { class: 'call-count' })),
    h('div', { class: 'grid' }), h('div', { class: 'call-bar' }));
  C.ui = ui; document.body.append(ui);
  const t = tileEl('me', S.me, true); const v = $('video', t); v.srcObject = C.local; watch(C.local, t);
  updateLocal(); drawBar();
}
function updateLocal() {
  const t = C.tiles.get('me'); if (!t) return;
  t.classList.toggle('novid', !(C.cam || C.screen) || !C.local.getVideoTracks().length);
  t.classList.toggle('screen', !!C.screen);
  $('.mi', t).replaceChildren(...(C.muted ? [ic('micoff')] : []));
  $('video', t).srcObject = C.screen || C.local;
}
function drawBar() {
  const bar = $('.call-bar', C.ui);
  fill(bar,
    h('button', { class: 'ibtn' + (C.muted ? ' red' : ''), title: 'Microfone', onclick: toggleMute }, ic(C.muted ? 'micoff' : 'mic')),
    h('button', { class: 'ibtn' + (C.cam ? ' on' : ''), title: 'Câmera', onclick: toggleCam }, ic(C.cam ? 'video' : 'videooff')),
    navigator.mediaDevices.getDisplayMedia ? h('button', { class: 'ibtn' + (C.screen ? ' on' : ''), title: 'Compartilhar tela', onclick: toggleScreen }, ic('screen')) : null,
    h('button', { class: 'ibtn', title: 'Adicionar pessoa', onclick: addPeople }, ic('plus')),
    S.settings.float ? h('button', { class: 'ibtn', title: 'Janela flutuante (PiP)', onclick: pip }, ic('pip')) : null,
    S.settings.float ? h('button', { class: 'ibtn', title: 'Minimizar', onclick: minimize }, ic('min')) : null,
    h('button', { class: 'ibtn red', title: 'Encerrar', onclick: () => endCall(true) }, ic('phone')));
  $('.call-bar .ibtn.red:last-child', C.ui).firstChild.style.transform = 'rotate(135deg)';
}
function startTimer() {
  clearInterval(C.timer);
  const tick = () => { const s = fmtDur(Date.now() - C.startedAt); const e = $('.call-time', C.ui); if (e) e.textContent = s; const b = $('.bt'); if (b) b.textContent = s; };
  tick(); C.timer = setInterval(tick, 1000);
}
const sig = (sid, data) => S.sock.emit('call:signal', { to: sid, data });
function sendState() { if (C) S.sock.emit('call:state', { cam: C.cam || !!C.screen, mic: !C.muted }); }
function mkPeer(sid, user, polite) {
  const pc = new RTCPeerConnection({ iceServers: S.ice });
  const p = { sid, user, pc, polite, making: false, ignore: false, stream: new MediaStream(), cam: undefined, mic: true };
  C.peers.set(sid, p);
  C.local.getTracks().forEach(t => pc.addTrack(t, C.local));
  const t = tileEl(sid, user, false); $('video', t).srcObject = p.stream; watch(p.stream, t);
  pc.ontrack = e => {
    if (!p.stream.getTracks().includes(e.track)) p.stream.addTrack(e.track);
    ['mute', 'unmute', 'ended'].forEach(ev => e.track.addEventListener(ev, () => updateTile(p)));
    updateTile(p); $('video', t).play?.().catch(() => { });
  };
  pc.onicecandidate = e => e.candidate && sig(sid, { candidate: e.candidate });
  pc.onnegotiationneeded = async () => { try { p.making = true; await pc.setLocalDescription(); sig(sid, { description: pc.localDescription }); } catch (e) { console.error(e); } finally { p.making = false; } };
  pc.onconnectionstatechange = () => { if (pc.connectionState === 'failed') pc.restartIce(); };
  updateCount(); return p;
}
function updateTile(p) {
  const t = C && C.tiles.get(p.sid); if (!t) return;
  const hasV = p.cam !== false && p.stream.getVideoTracks().some(x => x.readyState === 'live' && !x.muted);
  t.classList.toggle('novid', !hasV);
  $('.mi', t).replaceChildren(...(p.mic === false ? [ic('micoff')] : []));
}
function updateCount() { const e = $('.call-count', C.ui); if (e) e.textContent = (C.peers.size + 1) + ' participante(s)'; }
function dropPeer(sid) {
  const p = C.peers.get(sid); if (!p) return;
  p.pc.close(); C.peers.delete(sid); C.tiles.get(sid)?.remove(); C.tiles.delete(sid); updateCount();
}
async function onSignal({ from, user, data }) {
  if (!C) return;
  const p = C.peers.get(from) || mkPeer(from, user, true), pc = p.pc;
  try {
    if (data.description) {
      const d = data.description, collision = d.type === 'offer' && (p.making || pc.signalingState !== 'stable');
      p.ignore = !p.polite && collision; if (p.ignore) return;
      await pc.setRemoteDescription(d);
      if (d.type === 'offer') { await pc.setLocalDescription(); sig(from, { description: pc.localDescription }); }
    } else if (data.candidate) {
      try { await pc.addIceCandidate(data.candidate); } catch (e) { if (!p.ignore) throw e; }
    }
  } catch (e) { console.error(e); }
}
function onJoined({ sid, user, startedAt }) {
  if (!C) return;
  toast(user.name + ' entrou na chamada');
  if (!C.startedAt) { C.startedAt = startedAt; startTimer(); }
  sendState();
}
async function startCall(f, video) {
  if (C) return addToCall(f);
  let local; try { local = await getMedia({ audio: { echoCancellation: true, noiseSuppression: true }, video: video ? { width: 1280, height: 720 } : false }, video ? 'a câmera e o microfone' : 'o microfone'); } catch (_) { return; }
  newCall(local, video, null); showCallUI(f.name);
  const r = await emit('call:invite', { to: f.id, video });
  if (r.error) { toast(r.error); return endCall(false); }
  C.room = r.room; loadCalls();
}
async function addToCall(f) {
  if (!C.room) return toast('Aguarde a chamada iniciar');
  const r = await emit('call:invite', { to: f.id, room: C.room, video: C.video });
  toast(r.error || 'Convite enviado para ' + f.name);
}
function addPeople() {
  const inCall = new Set([...C.peers.values()].map(p => p.user.id));
  const list = S.friends.filter(f => f.status === 'accepted' && !f.blocked && !inCall.has(f.id));
  const o = modal('Adicionar à chamada', list.length ? h('div', {}, list.map(f => h('div', { class: 'item click', onclick: () => { o.remove(); addToCall(f); } }, avatar(f), h('div', { class: 'grow' }, f.name), h('small', {}, f.online ? 'online' : 'offline')))) : 'Nenhum amigo disponível.', [['Fechar']]);
}
function toggleMute() { C.muted = !C.muted; C.local.getAudioTracks().forEach(t => t.enabled = !C.muted); updateLocal(); drawBar(); sendState(); }
async function toggleCam() {
  const vt = C.local.getVideoTracks()[0];
  if (!vt) {
    let s; try { s = await getMedia({ video: { width: 1280, height: 720 } }, 'a câmera'); } catch (_) { return; }
    const t = s.getVideoTracks()[0]; C.local.addTrack(t); C.cam = true;
    C.peers.forEach(p => p.pc.addTrack(t, C.local));
  } else { vt.enabled = !vt.enabled; C.cam = vt.enabled; }
  updateLocal(); drawBar(); sendState();
}
async function toggleScreen() {
  if (C.screen) return stopScreen();
  let st; try { st = await navigator.mediaDevices.getDisplayMedia({ video: true }); } catch (e) { return e.name === 'NotAllowedError' ? toast('Compartilhamento cancelado ou não permitido') : permHelp('a tela', e); }
  C.screen = st; const tr = st.getVideoTracks()[0]; tr.onended = stopScreen;
  C.peers.forEach(p => { const s = p.pc.getSenders().find(x => x.track && x.track.kind === 'video'); if (s) { p.replaced = true; s.replaceTrack(tr); } else { p.replaced = false; p.pc.addTrack(tr, st); } });
  updateLocal(); drawBar(); sendState();
}
function stopScreen() {
  if (!C || !C.screen) return;
  const tr = C.screen.getVideoTracks()[0], cam = C.local.getVideoTracks()[0];
  C.peers.forEach(p => { const s = p.pc.getSenders().find(x => x.track === tr); if (!s) return; if (p.replaced) s.replaceTrack(cam || null); else p.pc.removeTrack(s); });
  C.screen.getTracks().forEach(t => t.stop()); C.screen = null; updateLocal(); drawBar(); sendState();
}
async function pip() {
  try {
    if (document.pictureInPictureElement) return document.exitPictureInPicture();
    let v = [...C.tiles.entries()].filter(([id, t]) => id !== 'me' && !t.classList.contains('novid')).map(([, t]) => $('video', t))[0];
    if (!v) {
      const cv = h('canvas', { width: 320, height: 180 }), cx = cv.getContext('2d'), vid = h('video', { muted: true, playsInline: true, class: 'hidvid' });
      const draw = () => { cx.fillStyle = '#071A38'; cx.fillRect(0, 0, 320, 180); cx.fillStyle = '#1677FF'; cx.beginPath(); cx.arc(160, 70, 34, 0, 7); cx.fill(); cx.fillStyle = '#fff'; cx.font = 'bold 18px sans-serif'; cx.textAlign = 'center'; cx.fillText('DarkCall', 160, 130); cx.fillText(C.startedAt ? fmtDur(Date.now() - C.startedAt) : 'Chamando…', 160, 156); };
      draw(); const iv = setInterval(draw, 1000); vid.srcObject = cv.captureStream(5); document.body.append(vid); await vid.play();
      vid.addEventListener('leavepictureinpicture', () => { clearInterval(iv); vid.remove(); }); return vid.requestPictureInPicture();
    }
    await v.requestPictureInPicture();
  } catch (e) { toast('Janela flutuante não é suportada neste navegador'); }
}
try { navigator.mediaSession && navigator.mediaSession.setActionHandler('enterpictureinpicture', () => { if (C && S.settings.float) pip(); }); } catch (_) { }
function minimize() {
  C.ui.classList.add('hidden');
  const b = h('div', { class: 'bubble-float', style: { right: '8px', top: '40%' }, title: 'Voltar à chamada' }, ic('phone'), h('span', { class: 'bt', style: { position: 'absolute', bottom: '-18px', fontSize: '11px', background: 'rgba(0,0,0,.6)', padding: '0 6px', borderRadius: '9px' } }));
  let sx, sy, ox, oy, moved = false;
  b.addEventListener('pointerdown', e => { b.setPointerCapture(e.pointerId); const r = b.getBoundingClientRect(); sx = e.clientX; sy = e.clientY; ox = r.left; oy = r.top; moved = false; b.classList.add('drag'); });
  b.addEventListener('pointermove', e => { if (!b.hasPointerCapture(e.pointerId)) return; if (Math.abs(e.clientX - sx) + Math.abs(e.clientY - sy) > 6) moved = true; b.style.right = 'auto'; b.style.left = Math.min(innerWidth - 64, Math.max(0, ox + e.clientX - sx)) + 'px'; b.style.top = Math.min(innerHeight - 90, Math.max(0, oy + e.clientY - sy)) + 'px'; });
  b.addEventListener('pointerup', () => {
    b.classList.remove('drag');
    if (!moved) { b.remove(); C.bubble = null; C.ui.classList.remove('hidden'); return; }
    b.style.left = (b.getBoundingClientRect().left + 32 < innerWidth / 2 ? 8 : innerWidth - 72) + 'px';
  });
  document.body.append(b); C.bubble = b; if (C.startedAt) startTimer();
}
function onIncoming(inc) {
  if (C || S.incoming) { S.sock.emit('call:decline', { room: inc.room }); return; }
  S.incoming = inc;
  const grp = inc.members.length > 1;
  const el = h('div', { class: 'incoming', id: 'incoming' }, avatar(inc.from, 'xxl'), h('h2', {}, inc.from.name),
    h('p', { class: 'mut' }, grp ? 'Convite para chamada em grupo com ' + inc.members.map(m => m.name).join(', ') : inc.video ? 'Chamada de vídeo' : 'Chamada de áudio'),
    h('div', { class: 'row', style: { gap: '48px', marginTop: '20px' } },
      h('button', { class: 'ibtn red', title: 'Recusar', onclick: () => { S.sock.emit('call:decline', { room: inc.room }); hideIncoming(); } }, (() => { const i = ic('phone'); i.style.transform = 'rotate(135deg)'; return i; })()),
      h('button', { class: 'ibtn green', title: 'Atender', onclick: answer }, ic(inc.video ? 'video' : 'phone'))));
  document.body.append(el); startRing();
  notify('Chamada de ' + inc.from.name, inc.video ? 'Chamada de vídeo' : 'Chamada de áudio', 'call' + inc.room, { peer: inc.from.id });
}
function hideIncoming() { stopRing(); $('#incoming')?.remove(); S.incoming = null; }
async function answer() {
  const inc = S.incoming; hideIncoming();
  let local; try { local = await getMedia({ audio: { echoCancellation: true, noiseSuppression: true }, video: inc.video ? { width: 1280, height: 720 } : false }, inc.video ? 'a câmera e o microfone' : 'o microfone'); } catch (_) { S.sock.emit('call:decline', { room: inc.room }); return; }
  newCall(local, inc.video, inc.room); showCallUI(inc.from.name);
  const r = await emit('call:accept', { room: inc.room });
  if (r.error) { toast(r.error); return endCall(false); }
  C.startedAt = r.startedAt; startTimer();
  r.peers.forEach(p => mkPeer(p.sid, p.user, false));
  sendState(); loadCalls();
}
function endCall(notifyServer) {
  if (!C) return;
  if (notifyServer && S.sock) S.sock.emit('call:leave');
  clearInterval(C.timer); C.watchers.forEach(clearInterval);
  C.peers.forEach(p => p.pc.close());
  C.local.getTracks().forEach(t => t.stop()); C.screen && C.screen.getTracks().forEach(t => t.stop());
  C.ui.remove(); C.bubble && C.bubble.remove();
  if (document.pictureInPictureElement) document.exitPictureInPicture().catch(() => { });
  C = null; setTimeout(loadCalls, 400);
}
window.addEventListener('beforeunload', () => { if (C && S.sock) S.sock.emit('call:leave'); });

boot();
