self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', e => e.waitUntil(clients.claim()));
self.addEventListener('push', e => {
  let d = {};
  try { d = e.data.json(); } catch (_) {}
  e.waitUntil(self.registration.showNotification(d.title || 'DarkCall', {
    body: d.body || '', tag: d.tag, icon: '/icon-192.png', badge: '/icon-192.png',
    data: d, vibrate: [200, 100, 200], requireInteraction: !!d.call
  }));
});
self.addEventListener('notificationclick', e => {
  e.notification.close();
  const data = e.notification.data || {};
  e.waitUntil(clients.matchAll({ type: 'window', includeUncontrolled: true }).then(list => {
    if (list.length) { list[0].postMessage({ open: data }); return list[0].focus(); }
    return clients.openWindow('/');
  }));
});
